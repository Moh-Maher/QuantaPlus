var annotated_dup =
[
    [ "QuantaPlus", "da/dc8/namespaceQuantaPlus.html", [
      [ "AngularMomentum", "dc/d98/classQuantaPlus_1_1AngularMomentum.html", "dc/d98/classQuantaPlus_1_1AngularMomentum" ],
      [ "Bra", "d1/d98/classQuantaPlus_1_1Bra.html", "d1/d98/classQuantaPlus_1_1Bra" ],
      [ "CGCcoeff", "dd/d45/classQuantaPlus_1_1CGCcoeff.html", "dd/d45/classQuantaPlus_1_1CGCcoeff" ],
      [ "Ket", "df/d94/classQuantaPlus_1_1Ket.html", "df/d94/classQuantaPlus_1_1Ket" ],
      [ "QM_operator", "d2/dbd/classQuantaPlus_1_1QM__operator.html", "d2/dbd/classQuantaPlus_1_1QM__operator" ]
    ] ],
    [ "ElapsedTime", "dd/d83/classElapsedTime.html", null ],
    [ "LaTex", "de/df8/classLaTex.html", null ],
    [ "Output", "dc/d13/classOutput.html", "dc/d13/classOutput" ]
];