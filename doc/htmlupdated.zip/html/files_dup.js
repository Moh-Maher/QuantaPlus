var files_dup =
[
    [ "quantaplus", "dir_c07d0ee52b103035834dd6c1e406d1ad.html", "dir_c07d0ee52b103035834dd6c1e406d1ad" ]
];