var latex_8h =
[
    [ "LaTex", "de/df8/classLaTex.html", null ]
];