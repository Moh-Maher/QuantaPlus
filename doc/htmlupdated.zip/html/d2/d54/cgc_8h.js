var cgc_8h =
[
    [ "QuantaPlus::CGCcoeff", "dd/d45/classQuantaPlus_1_1CGCcoeff.html", "dd/d45/classQuantaPlus_1_1CGCcoeff" ],
    [ "operator<<", "d2/d54/cgc_8h.html#a456793d842fc471e04c7cca64dff2248", null ]
];