var modules =
[
    [ "QuantaPlus", "d6/d82/group__QuantaPlus.html", "d6/d82/group__QuantaPlus" ]
];