var namespaces_dup =
[
    [ "QuantaPlus", "da/dc8/namespaceQuantaPlus.html", "da/dc8/namespaceQuantaPlus" ]
];