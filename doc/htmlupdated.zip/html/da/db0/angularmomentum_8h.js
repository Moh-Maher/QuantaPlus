var angularmomentum_8h =
[
    [ "QuantaPlus::AngularMomentum< T >", "dc/d98/classQuantaPlus_1_1AngularMomentum.html", "dc/d98/classQuantaPlus_1_1AngularMomentum" ]
];