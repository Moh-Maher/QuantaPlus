var braket_8h =
[
    [ "QuantaPlus::Ket< T >", "df/d94/classQuantaPlus_1_1Ket.html", "df/d94/classQuantaPlus_1_1Ket" ],
    [ "QuantaPlus::Bra< T >", "d1/d98/classQuantaPlus_1_1Bra.html", "d1/d98/classQuantaPlus_1_1Bra" ]
];