var hierarchy =
[
    [ "QuantaPlus::CGCcoeff", "dd/d45/classQuantaPlus_1_1CGCcoeff.html", null ],
    [ "ElapsedTime", "dd/d83/classElapsedTime.html", null ],
    [ "LaTex", "de/df8/classLaTex.html", null ],
    [ "Eigen::Matrix", null, [
      [ "QuantaPlus::AngularMomentum< T >", "dc/d98/classQuantaPlus_1_1AngularMomentum.html", null ],
      [ "QuantaPlus::Bra< T >", "d1/d98/classQuantaPlus_1_1Bra.html", null ],
      [ "QuantaPlus::Ket< T >", "df/d94/classQuantaPlus_1_1Ket.html", null ],
      [ "QuantaPlus::QM_operator< T >", "d2/dbd/classQuantaPlus_1_1QM__operator.html", null ]
    ] ],
    [ "Output", "dc/d13/classOutput.html", null ]
];