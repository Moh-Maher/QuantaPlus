var searchData=
[
  ['stringmatrix_0',['StringMatrix',['../da/dc8/namespaceQuantaPlus.html#a0bb78b439295e3b0683a3395f20cc915',1,'QuantaPlus']]]
];
