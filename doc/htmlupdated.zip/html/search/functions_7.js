var searchData=
[
  ['latex_0',['LaTex',['../d8/d84/classQuantaPlus_1_1LaTex.html#ab6e26ce23ca32432f8b633a523d1a1fd',1,'QuantaPlus::LaTex::LaTex()'],['../d8/d84/classQuantaPlus_1_1LaTex.html#a842d773064ec738ef04e0e805d240aef',1,'QuantaPlus::LaTex::LaTex(std::string filename)']]],
  ['latexmath_1',['LaTexMath',['../d8/d84/classQuantaPlus_1_1LaTex.html#a6d61490c4dcd0abf3ec2aef157c50b56',1,'QuantaPlus::LaTex']]]
];
