var searchData=
[
  ['b2_5felec_5fcharge_0',['B2_ELEC_CHARGE',['../da/dc8/namespaceQuantaPlus.html#ad83b49275e4f7b1ce8fc069ea3e33447',1,'QuantaPlus']]],
  ['b_5felec_5fcharge_1',['B_ELEC_CHARGE',['../da/dc8/namespaceQuantaPlus.html#a5bc730bd96c438b808b8cfe7d939213e',1,'QuantaPlus']]]
];
