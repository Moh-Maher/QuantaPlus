var searchData=
[
  ['b2_5felec_5fcharge_0',['B2_ELEC_CHARGE',['../da/dc8/namespaceQuantaPlus.html#ad83b49275e4f7b1ce8fc069ea3e33447',1,'QuantaPlus']]],
  ['b_5felec_5fcharge_1',['B_ELEC_CHARGE',['../da/dc8/namespaceQuantaPlus.html#a5bc730bd96c438b808b8cfe7d939213e',1,'QuantaPlus']]],
  ['beginlatex_2',['BeginLaTex',['../d8/d84/classQuantaPlus_1_1LaTex.html#a90d75fec58234179a6ce191d55689df0',1,'QuantaPlus::LaTex']]],
  ['bibliography_3',['Bibliography',['../d0/de3/citelist.html',1,'']]],
  ['bra_4',['Bra',['../d1/d98/classQuantaPlus_1_1Bra.html#af6f1caf2e96903d7948312c4405b26f4',1,'QuantaPlus::Bra::Bra()'],['../d1/d98/classQuantaPlus_1_1Bra.html#a1eab24b6b8a7076307019ed51e85029a',1,'QuantaPlus::Bra::Bra(int col)'],['../d1/d98/classQuantaPlus_1_1Bra.html#a6e659cc599dc0a6ad18e42bfd7196c92',1,'QuantaPlus::Bra::Bra(const Eigen::MatrixBase&lt; Derived &gt; &amp;other)'],['../d1/d98/classQuantaPlus_1_1Bra.html',1,'QuantaPlus::Bra&lt; T &gt;']]],
  ['braket_2eh_5',['braket.h',['../da/d10/braket_8h.html',1,'']]]
];
