var searchData=
[
  ['endlatex_0',['EndLaTex',['../d8/d84/classQuantaPlus_1_1LaTex.html#a1abfa4ee056961eab62d869ab045f9e4',1,'QuantaPlus::LaTex']]]
];
