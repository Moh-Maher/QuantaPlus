var searchData=
[
  ['quantaplus_0',['QuantaPlus',['../d6/d82/group__QuantaPlus.html',1,'']]]
];
