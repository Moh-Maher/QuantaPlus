var searchData=
[
  ['quantaplus_0',['QuantaPlus',['../da/dc8/namespaceQuantaPlus.html',1,'']]]
];
