var searchData=
[
  ['angularmomentum_0',['AngularMomentum',['../dc/d98/classQuantaPlus_1_1AngularMomentum.html',1,'QuantaPlus']]]
];
