var searchData=
[
  ['bibliography_0',['Bibliography',['../d0/de3/citelist.html',1,'']]]
];
