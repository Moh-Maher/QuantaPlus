var searchData=
[
  ['halfinteger_0',['halfInteger',['../da/dc8/namespaceQuantaPlus.html#a6210f298a3163e63970a7a0d33fda73f',1,'QuantaPlus']]]
];
