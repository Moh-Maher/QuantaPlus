var searchData=
[
  ['latex_2eh_0',['latex.h',['../dd/d14/latex_8h.html',1,'']]]
];
