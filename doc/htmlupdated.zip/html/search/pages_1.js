var searchData=
[
  ['quantaplus_0',['QuantaPlus',['../index.html',1,'']]]
];
