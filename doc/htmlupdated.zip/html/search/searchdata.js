var indexSectionsWithContent =
{
  0: "abcdeghijklmnopqrstuvwz~",
  1: "abcekloq",
  2: "q",
  3: "abclou",
  4: "abcehiklmnoqrstvw~",
  5: "bcdeghjmpqstuz",
  6: "q",
  7: "bq"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Modules",
  7: "Pages"
};

