var searchData=
[
  ['d2_5felec_5fcharge_0',['D2_ELEC_CHARGE',['../da/dc8/namespaceQuantaPlus.html#a29e87e5766f7055e3208368b0235b734',1,'QuantaPlus']]],
  ['d_5felec_5fcharge_1',['D_ELEC_CHARGE',['../da/dc8/namespaceQuantaPlus.html#aca56d02622f7294f99d485fb72c34548',1,'QuantaPlus']]]
];
