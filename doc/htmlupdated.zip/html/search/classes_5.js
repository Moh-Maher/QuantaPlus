var searchData=
[
  ['latex_0',['LaTex',['../d8/d84/classQuantaPlus_1_1LaTex.html',1,'QuantaPlus']]]
];
