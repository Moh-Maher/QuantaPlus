var searchData=
[
  ['beginlatex_0',['BeginLaTex',['../d8/d84/classQuantaPlus_1_1LaTex.html#a90d75fec58234179a6ce191d55689df0',1,'QuantaPlus::LaTex']]],
  ['bra_1',['Bra',['../d1/d98/classQuantaPlus_1_1Bra.html#af6f1caf2e96903d7948312c4405b26f4',1,'QuantaPlus::Bra::Bra()'],['../d1/d98/classQuantaPlus_1_1Bra.html#a1eab24b6b8a7076307019ed51e85029a',1,'QuantaPlus::Bra::Bra(int col)'],['../d1/d98/classQuantaPlus_1_1Bra.html#a6e659cc599dc0a6ad18e42bfd7196c92',1,'QuantaPlus::Bra::Bra(const Eigen::MatrixBase&lt; Derived &gt; &amp;other)']]]
];
