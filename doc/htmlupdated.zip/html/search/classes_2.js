var searchData=
[
  ['cgccoeff_0',['CGCcoeff',['../dd/d45/classQuantaPlus_1_1CGCcoeff.html',1,'QuantaPlus']]]
];
