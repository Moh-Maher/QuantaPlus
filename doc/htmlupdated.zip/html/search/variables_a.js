var searchData=
[
  ['s2_5felec_5fcharge_0',['S2_ELEC_CHARGE',['../da/dc8/namespaceQuantaPlus.html#a288ec8a9b9839e7a1728897604d73d45',1,'QuantaPlus']]],
  ['s_5felec_5fcharge_1',['S_ELEC_CHARGE',['../da/dc8/namespaceQuantaPlus.html#aeda4e7d3a227593f7e79fa53b88be777',1,'QuantaPlus']]],
  ['speed_5fof_5flight_2',['SPEED_OF_LIGHT',['../da/dc8/namespaceQuantaPlus.html#ab0a809fee2ac98783ddfa6053318800c',1,'QuantaPlus']]]
];
