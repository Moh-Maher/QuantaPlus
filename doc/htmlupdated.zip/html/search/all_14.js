var searchData=
[
  ['validinteger_0',['validInteger',['../da/dc8/namespaceQuantaPlus.html#ad6eb262dc23d879cb79c6ca28179a94a',1,'QuantaPlus']]]
];
