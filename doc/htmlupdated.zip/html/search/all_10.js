var searchData=
[
  ['resultprint_0',['ResultPrint',['../da/dc8/namespaceQuantaPlus.html#a1002abc85cb4fc5ceba7c81883ce25dd',1,'QuantaPlus']]],
  ['rotationbyangle_1',['RotationByAngle',['../dc/d98/classQuantaPlus_1_1AngularMomentum.html#a2d44373d1129836d7c217f35871bbf80',1,'QuantaPlus::AngularMomentum']]]
];
