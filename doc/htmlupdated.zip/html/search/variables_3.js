var searchData=
[
  ['electron_5fmass_0',['ELECTRON_MASS',['../da/dc8/namespaceQuantaPlus.html#a6701f5b3640b4db00af5da41a2018533',1,'QuantaPlus']]]
];
