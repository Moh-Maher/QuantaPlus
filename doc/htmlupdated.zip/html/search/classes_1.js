var searchData=
[
  ['bra_0',['Bra',['../d1/d98/classQuantaPlus_1_1Bra.html',1,'QuantaPlus']]]
];
