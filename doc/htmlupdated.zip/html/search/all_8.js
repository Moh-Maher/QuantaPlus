var searchData=
[
  ['j_0',['j',['../dd/d45/classQuantaPlus_1_1CGCcoeff.html#a0fd804249943d2c74ccd0de68dc07077',1,'QuantaPlus::CGCcoeff']]],
  ['j1_1',['j1',['../dd/d45/classQuantaPlus_1_1CGCcoeff.html#afcce9cee0b0dc1cbd2468688ebd1c674',1,'QuantaPlus::CGCcoeff']]],
  ['j2_2',['j2',['../dd/d45/classQuantaPlus_1_1CGCcoeff.html#a22873a2cc2bf5ac51e85027250a48856',1,'QuantaPlus::CGCcoeff']]]
];
