var searchData=
[
  ['qm_5foperator_0',['QM_operator',['../d2/dbd/classQuantaPlus_1_1QM__operator.html#acc6794ebcceb99443927303aaff5b906',1,'QuantaPlus::QM_operator::QM_operator()'],['../d2/dbd/classQuantaPlus_1_1QM__operator.html#a93309d3cda541d70eed10ca2e3a70c1b',1,'QuantaPlus::QM_operator::QM_operator(int row, int col)'],['../d2/dbd/classQuantaPlus_1_1QM__operator.html#a3b14cbed10261157c5a4b1797d090cf6',1,'QuantaPlus::QM_operator::QM_operator(const Eigen::MatrixBase&lt; Derived &gt; &amp;other)']]]
];
