var searchData=
[
  ['nresultprint_0',['NResultPrint',['../da/dc8/namespaceQuantaPlus.html#a87942db7e68bba48516039f085744a5e',1,'QuantaPlus']]]
];
