var searchData=
[
  ['elapsedtime_0',['ElapsedTime',['../d9/df3/classQuantaPlus_1_1ElapsedTime.html',1,'QuantaPlus']]]
];
