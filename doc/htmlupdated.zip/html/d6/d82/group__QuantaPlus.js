var group__QuantaPlus =
[
    [ "QuantaPlus", "da/dc8/namespaceQuantaPlus.html", null ]
];