var operators_8h =
[
    [ "QuantaPlus::QM_operator< T >", "d2/dbd/classQuantaPlus_1_1QM__operator.html", "d2/dbd/classQuantaPlus_1_1QM__operator" ]
];